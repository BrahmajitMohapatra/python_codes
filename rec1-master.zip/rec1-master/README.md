# extracting required data from json file
{"monday":{"9-10":6,"10-11":6,...},
"tuesday":{"9-10":6,"10-11":6,...},





}
